import os
import shutil

class FileManager:
    def __init__(self, base_path):
        self.base_path = base_path

        # Auto-create directory if it doesn't exist
        if not os.path.exists(self.base_path):
            os.makedirs(self.base_path)
            print(f"Created path: {self.base_path}")

    def list_file(self):
        print("\nFiles and Folders:")
        items = os.listdir(self.base_path)
        if not items:
            print("Directory is empty.")
            return
        for item in items:
            print(item)

    def organize_by_extension(self):
        files= os.listdir(self.base_path)
        for filename in files:
            file_path = os.path.join(self.base_path, filename)
            if os.path.isfile(file_path):
                ext = filename.split('.')[-1] if '.' in filename else 'no_extension'
                print(f"Found extension: {ext}")
                folder = os.path.join(self.base_path, ext.upper())
                os.makedirs(folder, exist_ok=True)
                shutil.move(file_path, os.path.join(folder, filename))
        
        print("Organized by extension!")
    
    def remove_file(self, filename):
        file_path = os.path.join(self.base_path, filename)
        if os.path.exists(file_path) and os.path.isfile(file_path):
            os.remove(file_path)
            print(f"Removed file: {filename}")
        else:
            print(f"File not found: {filename}")
    
    def add_file(self, filename, content):
        file_path = os.path.join(self.base_path, filename)
        with open(file_path, 'w') as f:
            f.write(content)
        print(f"Added file: {filename}")

# Run it
if __name__ == "__main__":
    path = "Python"
    fm = FileManager(path)
    fm.list_file()
    fm.organize_by_extension()
    fm.remove_file("testfile.txt")

