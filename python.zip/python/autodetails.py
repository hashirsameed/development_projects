from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import pandas as pd
import time

# Setup Chrome
chrome_path = r"C:\Users\hp\Downloads\chromedriver-win64\chromedriver-win64\chromedriver.exe" # Change to your path
options = Options()
options.add_argument("--headless")
options.add_argument("--log-level=3")
driver = webdriver.Chrome(service=Service(chrome_path), options=options)

# ----- User Input -----
search_query = input("🔍 Enter search query (e.g., 'hospitals in Lahore'): ")

# ----- Search on Google Maps -----
driver.get("https://www.google.com/maps")
time.sleep(3)

search_box = driver.find_element(By.ID, "searchboxinput")
search_box.send_keys(search_query)
search_box.send_keys(Keys.ENTER)
time.sleep(5)

# Scroll sidebar to load more results until no new results are loaded
previous_count = 0
max_attempts = 20  # Safety limit to prevent infinite loop
while True:
    driver.execute_script("document.querySelectorAll('div[role=\"feed\"]')[0].scrollBy(0,1000)")
    time.sleep(2)
    current_count = len(driver.find_elements(By.CLASS_NAME, "Nv2PK"))
    if current_count == previous_count or max_attempts <= 0:
        break
    previous_count = current_count
    max_attempts -= 1

# Extract listings from sidebar
listings = driver.find_elements(By.CLASS_NAME, "Nv2PK")
print(f"\n📦 Found {len(listings)} listings\n")

data = []

for i, item in enumerate(listings):
    try:
        name = item.find_element(By.CLASS_NAME, "qBF1Pd").text
    except:
        name = "N/A"
    try:
        full_text = item.text
        lines = full_text.split("\n")
        # Extract phone number (lines containing '+' or pure digits, but skip if '021' is present)
        phone = "Not found"
        for line in lines:
            if ('021' not in line and ('+' in line or line.strip().isdigit())):
                phone = line
                if phone.strip().isdigit():
                    phone = f"+92 {phone}"
                break
        # Extract opening hours (lines containing 'Open', 'Closed', or 'Closes')
        opening_hours = next((line for line in lines if 'Open' in line or 'Closed' in line or 'Closes' in line), "Not found")
        # Extract address (typically the line after the name, but before phone or hours)
        address_index = 1 if len(lines) > 1 else 0
        address = lines[address_index] if lines[address_index] not in [phone, opening_hours] else "Not found"
    except:
        phone = "Not found"
        opening_hours = "Not found"
        address = "Not found"

    print(f"[{i+1}] {name} | 📞 {phone} | ⏰ {opening_hours} | 📍 {address}")
    data.append({"Name": name, "Phone": phone, "Opening Hours": opening_hours, "Address": address})

# Save to CSV
df = pd.DataFrame(data)
df.to_csv("gmap_sidebar_results.csv", index=False, encoding='utf-8-sig')

driver.quit()
print("\n✅ Done! Results saved in 'gmap_sidebar_results.csv'")