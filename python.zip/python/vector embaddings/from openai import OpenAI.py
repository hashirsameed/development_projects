from openai import OpenAI
client = OpenAI(api_key="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")

client.embeddings.create(
  model="text-embedding-ada-002",
  input="The food was delicious and the waiter...",
  encoding_format="float"
)