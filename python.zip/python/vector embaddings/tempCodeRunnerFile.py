from sqlalchemy import create_engine
import pandas as pd
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

def fetch_data():
    # ✅ Use SQLAlchemy engine with pymysql
    engine = create_engine("mysql+pymysql://root:H%40shir321@127.0.0.1:3306/semantic")

    # ✅ Use only the engine here
    query = """
    SELECT p.prod_id, p.prod_name, d.prod_price, d.prod_model, d.prod_details
    FROM products p
    JOIN details d ON p.prod_id = d.prod_id;
    """
    df = pd.read_sql(query, engine)
    return df


products = fetch_data()
model = SentenceTransformer('all-MiniLM-L6-v2')
products_embaddings = model.encode(products["prod_name"].tolist())
print(products_embaddings.shape)

dimension = products_embaddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(np.array(products_embaddings))