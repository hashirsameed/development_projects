import pymysql
from sqlalchemy import create_engine
import pandas as pd
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
from fastapi import FastAPI
from pydantic import BaseModel
def fetch_data():
    # ✅ Use SQLAlchemy engine with pymysql
    engine = create_engine("mysql+pymysql://root:H%40shir321@127.0.0.1:3306/semantic")

    # ✅ Use only the engine here
    query = """
    SELECT p.prod_id, p.prod_name, d.prod_price, d.prod_model, d.prod_details
    FROM products p
    JOIN details d ON p.prod_id = d.prod_id;
    """
    df = pd.read_sql(query, engine)
    return df


products = fetch_data()
model = SentenceTransformer('all-MiniLM-L6-v2')
products_embaddings = model.encode(products["prod_name"].tolist())
print(products_embaddings.shape)

dimension = products_embaddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(np.array(products_embaddings))

# Step 3: API setup
app = FastAPI()

class Query(BaseModel):
    text: str

@app.post("/search")
def search_product(query: Query):
    query_embedding = model.encode([query.text])
    D, I = index.search(np.array(query_embedding), k=3)  # Top 3 results
    results = [products.iloc[i].to_dict() for i in I[0]]  # ✅ iloc se row access
    return {"query": query.text, "results": results}

result = search_product(Query(text="apple"))
print(result)

