import time
import sys
import os

# Typing effect function
def slow_type(text, delay=0.04):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

# Line break
def line():
    print("-" * 60)

def introduction():
    os.system('cls' if os.name == 'nt' else 'clear')
    slow_type("💔 A Letter for My WIFE 💔", 0.08) 
    line()
    slow_type("To: Mere Nakchary, My Love", 0.06)
    time.sleep(1)
    slow_type("From: Someone who deeply regrets losing you...\n")

def hoping():
    slow_type("Hey Laraib,")
    slow_type("I don’t know if you’ll read this fully, but I hope you do.")
    time.sleep(1.5)

def regret():
    line()
    slow_type("😔 My Regret", 0.06)
    slow_type("I know I broke your trust.")
    slow_type("I wish I could take back that moment. You didn’t deserve that pain.")
    slow_type("No excuse can fix it.")
    slow_type("But my feelings? They were always real.")
    slow_type("And I’ll spend my life proving it, if I have to.")
    time.sleep(2)

def memories():
    line()
    slow_type("🕰️ HUMARE YADEEIN", 0.06)
    memory_message = """
Mujhe ab bhi yaad h jb meine apko first time msg kiya tha, mein kitna dara hoa tha.
Mujhe andaza bhi ni tha k hum itna waqt saath guzaar kr yahan tk ayegy.

Humne saath mein bht up and downs dekhy, aur finally,
apni ammi ko humare itny effort k bd apke ghr bheja.
Humare ghr wale is baat pr agree bhi ho gye k graduation k bd hum baat agy bdhayegy.

Apse nikkah krna na sirf mere leye zaroori h, blke ap mere pillar bhi hain.

Apny mujhe us waqt pr support kiya jab mein tut raha tha...
Mein sach mein keh rha hn — koi or hoti to kab ka chhor chuki hoti.
Magar mujhe meri nakchary pr yaqeen h.

Or mein chahta hn k yeh yaqeen mazboot h — na k kamzoor.
So please… please forgive me.
Trust me, this time — not because I’m saying it, but because I mean it."""
    slow_type(memory_message, 0.04)

def poem():
    line()
    slow_type("📝 A Poem Just for You...", 0.06)
    poem_text = """
I broke something so fragile, your heart so pure,
Now silence fills where love was sure.  
But if time could heal what I destroyed,
I’d write a love not lost — but rewound, restored.
"""
    slow_type(poem_text, 0.05)
    time.sleep(2)

def last_words():
    line()
    slow_type("🌙 Mere Akhri Alfaaz Tumhare Liye...", 0.06)
    final_letter = """
ITNI SARE OR BADI BADI GHLTIYON K BD BHI MEIN APKO HURT KR RAHA HN 
MERE BATO SE MERE HARKATO SE
PR APNY KAHA THA APNI EFFORT KRO KUCH KRKE DEKHAO THEN YOU WILL FEEL THE SAME AS YOU COULD APKO APKI
KHUSHIYAN, APKE CHOTI CHOTI KHWAHISHY, APKO APKA CHOOZA WAPIS DENE K LEYE YEH EK CHOTI SE MEHNAT H

I KNOW THODE SE UNROMANTIC AND VERY LESS EFFORT H MAGAR BATO SE TO APKO MANA NI SKTA    
TO SOCHA YEH AZMA KR TRY KR LON 
HO SKTA H MUJHE MERE JAAN, MERE MUHABBAT, MERE PYARRI SE NAKCHARY MUJH PR YAQEEN KRNE LG JAYE 
OR USY JO IS BT K DR H K HUM KAHI ALAG NA HO JAYE NIKKAH SE PEHLY

TO ISKA YAQEEN DILANA THODA MUSHKIL H 
"""
    slow_type(final_letter, 0.04)

    slow_type("🤞 Qasam-e-Wafa 🤞", 0.06)
    qasam = """
PR MUJHE MERE RAB K KASAM — 
MERE ZUBAN SE YEH ALFAAZ KABHI NI NIKLYGY, MAZAK MEIN BHI NI:
"USE KRKE CHOD DEYA" — KABHI BHI NI.

I'm sorry again.
But more than sorry… I'm yours.
Always have been.
"""
    slow_type(qasam, 0.045)

    time.sleep(2)
    line()
    slow_type("~ End of Letter ~", 0.05)

# Running the full program in order
def run_love_letter():
    introduction()
    hoping()
    regret()
    memories()
    poem()
    last_words()

run_love_letter()
