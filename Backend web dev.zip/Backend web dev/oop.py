from Basic import myself
class Myclass:
    x = "I'm hashir sameed\nI'm a python developer\nand a data analyst"
class Data(myself):
    pass



# p2 = myself('Hashir Sameed', 20)
# print(p2.name)
# print(p2.age)
