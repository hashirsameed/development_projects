#try:
#     my_dict = {
#     "name": "Hashir Sameed",
#     "age": 20,
#     "country": "Pakistan",
#     "is_tall": True,
#     "is_student": True,
#     "Married": False,
#     "city": "Karachi",
#     "friends": ['ME','Laraib','Hamza','Muneeb']
# }
#     user_input = input("Enter a key to search in the dictionary: ")
#     if user_input in my_dict:
#         print(f"{user_input}: {my_dict[user_input]}")
#     else:
#         print("Key not found in the dictionary.")
# except:
#     print("Data not found in the dictionary.") 