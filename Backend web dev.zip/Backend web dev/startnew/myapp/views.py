from django.shortcuts import render
from django.http import HttpResponse
from .models import feature
# Create your views here.
def index(request):
    feature1 = feature()
    feature1.name = 'Fast'
    feature1.description = 'We are Fast'

    feature2 = feature()
    feature2.name = 'reliable'
    feature2.description = 'We are reliable'

    feature3 = feature()
    feature3.name = 'secure'
    feature3.description = 'We build secure websites'

    feature4 = feature()
    feature4.name = 'scalable'
    feature4.description = 'We build scalable websites'

    context = {
        'name': 'Hashir sameed',
        'age': 20,
        'city': 'Karachi',
        'nationality': 'Pakistan',
        'hobbies': ['coding', 'reading', 'gaming'],
        'skills': ['Python', 'Django'],

    }

    features = [feature1, feature2, feature3, feature4]

    return render(request, 'index.html', {'context': context, 'features': features})

def counter(request):
    text = request.POST['Text']
    amount_of_words = len(text.split())
    return render(request, 'counter.html',{'amount': amount_of_words})