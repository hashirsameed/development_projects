# print("hello world")
# a = 5
# b = 10
# a,b = b,a
# print(a)
# name = "John"
# greetings = "Hello"+ " " + name
# print(greetings)
# name_change = input("Enter your name: ")
# print(greetings.replace(name , name_change ))
# list
# list = [1, 2, 3, 4, 5]
# list1 = ["Hashir sameed"]
# list1.append("haris shaheer")
# list1[1] = "Laraib shehzad"
# print(list1)
# print(list1[0][0:6])
# for i in reversed(list1[1].split()):
#     print(i)
# print(len(list1[1]))
# print(len(list1[0]))
# countries = list(("Pakistan", "India", "Bangladesh", "Sri Lanka"))
# print(countries)
# print(type(countries))
# list1 = [1, 2, 3, 4, 5]
# list2 = [6, 7, 8, 9, 10]
# list3 = list1 + list2
# print(list3)
# list1.extend(list2)
# print(list1)
# list1.append(11)
# print(list1)
# list1.insert(0, 0)
# print(list1)
# list1.remove(0)
# print(list1)
# print(list1.count(1))
# list1.reverse()
# print(list1)
# list1.sort()
# print(list1)
# del list1[0]
# print(list1)
# countries = ('Hashir','Haris','Laraib')
# numbers = (1, 2, 3, 4, 5)
# print(countries[0])
# print(numbers)
# def letter():
#     name = input("Enter your name: ")
#     age = int(input("Enter your age: "))
#     print("Hello " + name + ", welcome to the Python course!"+" You are " + str(age) + " years old. Enjoy learning!")

# def add(a,b):
#     return a+b
#     # a = int(input("Enter first number: "))
#     # b = int(input("Enter second number: "))
#     # print("The sum of", a, "and", b, "is", a + b)

# def hello_world():
#     print("Hello World!")

# def list_name(*name):
#     print(name)

# hello_world()
# list_name('Hashir', 'Haris', 'Laraib')
# letter()
# print(add(5,6))
# my_dict = {
#     "name": "Hashir Sameed",
#     "age": 20,
#     "country": "Pakistan",
#     "is_tall": True,
#     "is_student": True,
#     "Married": False,
#     "city": "Karachi",
#     "friends": ['ME','Laraib','Hamza','Muneeb']
# }
# print(my_dict["name"])
# print(my_dict["friends"])
# #notice
# for key,value in my_dict.items():
#     print(key , value)
#     if key == "city":
#         break
# check notice
#for key,value in my_dict.items():
#     if key == "city":
#         break
#    print(key , value)
# try:
#     my_dict = {
#     "name": "Hashir Sameed",
#     "age": 20,
#     "country": "Pakistan",
#     "is_tall": True,
#     "is_student": True,
#     "Married": False,
#     "city": "Karachi",
#     "friends": ['ME','Laraib','Hamza','Muneeb']
# }
#     user_input = input("Enter a key to search in the dictionary: ")
#     if user_input in my_dict:
#         print(f"{user_input}: {my_dict[user_input]}")
#     else:
#         print("Key not found in the dictionary.")
# except:
#     print("Data not found in the dictionary.")         

# try:
#     my_dict2 = {
#     "name": "Hashir Sameed",
#     "age": 20,
#     "country": "Pakistan",
#     "is_tall": True,
#     "is_student": True,
#     "Married": False,
#     "city": "Karachi",
#     "friends": ['ME','Laraib','Hamza','Muneeb']
# }
#     user_input = str(input("Enter a key to search in the dictionary: "))
#     print(f"{user_input}: {my_dict2[user_input]}")
# except:
#     print("There is a ValueError in the input. Please enter a valid key.")
# else:
#     print("Key found in the dictionary.")
# file = open("countries.txt", "r")
# file = open("countries.txt", "w")
# print(file.readable())
# for files in file:
#     print(files)
# file.write("I'm Hashir Sameed\n")
# file.write("Brother is Haris Shaheer\n")
# file.close()
class myself:
    def info():
         my_dict2 = {
    "name": "Hashir Sameed",
    "age": 20,
    "country": "Pakistan",
    "is_tall": True,
    "is_student": True,
    "Married": False,
    "city": "Karachi",
    "friends": ['ME','Laraib','Hamza','Muneeb']
}

