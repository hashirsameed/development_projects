from django . shortcuts import render,redirect

def signup(request):
    return render(request,"signup.html")