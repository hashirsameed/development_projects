import numpy as np
import pandas as pd
import faiss
from sqlalchemy import create_engine
from sentence_transformers import SentenceTransformer
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

from django.shortcuts import render

def home(request):
    return render(request, "search/search.html")
# ---------- Fetch Data ----------
def fetch_data():
    engine = create_engine("mysql+pymysql://root:H%40shir321@127.0.0.1:3306/semantic")
    query = """
    SELECT p.prod_id, p.prod_name, d.prod_price, d.prod_model, d.prod_details
    FROM products p
    JOIN details d ON p.prod_id = d.prod_id;
    """
    df = pd.read_sql(query, engine)
    return df

# ---------- Load Data & Model Once ----------
products = fetch_data()
model = SentenceTransformer('all-MiniLM-L6-v2')
products_embeddings = model.encode(products["prod_name"].tolist())

dimension = products_embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(np.array(products_embeddings))


# ---------- API View ----------
@csrf_exempt
def search_product(request):
    try:
        if request.method == "POST":
            body = json.loads(request.body.decode("utf-8"))
            query_text = body.get("text", "")

        elif request.method == "GET":
            query_text = request.GET.get("text", "")

        else:
            return JsonResponse({"message": "Use GET ?text=... or POST {text: '...'}"})

        if not query_text:
            return JsonResponse({"error": "No text provided"}, status=400)

        query_embedding = model.encode([query_text])
        D, I = index.search(np.array(query_embedding), k=3)
        results = [products.iloc[i].to_dict() for i in I[0]]

        return JsonResponse({"query": query_text, "results": results}, safe=False)

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=400)

