from django.urls import path
from .views import search_product, home

urlpatterns = [
    path("", home, name="home"),
    path("search/", search_product, name="search_product"),
]

